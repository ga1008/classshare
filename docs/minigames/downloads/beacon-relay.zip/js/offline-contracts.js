window.LanGameOfflineContracts = {
  "config": {
    "formatVersion": 1,
    "gameKey": "beacon-relay",
    "version": "1.0.0",
    "title": "航标接力",
    "summary": "按海图线索依次点亮三座航标并引导船队返航。支持单人闯关，也支持 2–4 人合作轮流执舵。",
    "entry": "main.html",
    "icon": "static/beacon.png",
    "sdk": "js/lan-game-sdk.v1.js",
    "display": {
      "aspectRatio": "16:9",
      "stageTone": "dark"
    },
    "standalone": "solo",
    "modes": {
      "solo": true,
      "multiplayer": {
        "kind": "coop",
        "privateRooms": true,
        "minPlayers": 2,
        "maxPlayers": 4,
        "randomSizes": [
          2
        ]
      }
    },
    "capabilities": [
      "save.private",
      "room.chat"
    ],
    "contracts": {
      "writeback": "contracts/writeback.json",
      "rules": "contracts/rules.json"
    }
  },
  "writeback": {
    "formatVersion": 1,
    "series": "coast",
    "saveVersion": 1,
    "privateFields": {
      "sound": {
        "type": "boolean",
        "default": true
      },
      "mapStyle": {
        "type": "enum",
        "values": [
          "paper",
          "night"
        ],
        "default": "paper"
      },
      "mapPins": {
        "type": "document",
        "schema": {
          "type": "array",
          "maxItems": 12,
          "items": {
            "type": "integer",
            "minimum": 0,
            "maximum": 99
          }
        },
        "default": []
      }
    },
    "milestones": [
      {
        "id": "pier",
        "label": "码头",
        "resumeState": "atPier"
      },
      {
        "id": "bay",
        "label": "海湾",
        "resumeState": "atBay"
      },
      {
        "id": "cape",
        "label": "海角",
        "resumeState": "atCape"
      }
    ]
  },
  "rules": {
    "engine": "finite-turn-v1",
    "initial": "atPier",
    "states": {
      "atPier": {
        "outcome": null
      },
      "atBay": {
        "outcome": null
      },
      "atCape": {
        "outcome": null
      },
      "atChannel": {
        "outcome": null
      },
      "home": {
        "outcome": "completed"
      }
    },
    "transitions": [
      {
        "from": "atPier",
        "actor": "turn",
        "type": "light",
        "payload": {
          "bearing": "east"
        },
        "to": "atBay",
        "turn": "next"
      },
      {
        "from": "atBay",
        "actor": "turn",
        "type": "light",
        "payload": {
          "bearing": "south"
        },
        "to": "atCape",
        "turn": "next"
      },
      {
        "from": "atCape",
        "actor": "turn",
        "type": "light",
        "payload": {
          "bearing": "west"
        },
        "to": "atChannel",
        "turn": "next"
      },
      {
        "from": "atChannel",
        "actor": "turn",
        "type": "dock",
        "payload": {
          "signal": "allClear"
        },
        "to": "home",
        "turn": "keep"
      }
    ]
  }
};
