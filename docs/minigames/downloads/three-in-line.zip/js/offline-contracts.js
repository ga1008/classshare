window.LanGameOfflineContracts = {
  "config": {
    "formatVersion": 1,
    "gameKey": "three-in-line",
    "version": "1.0.0",
    "title": "双人连线棋",
    "summary": "两人轮流落子，在九宫棋盘中率先连成三子。",
    "entry": "main.html",
    "icon": "static/icon.png",
    "sdk": "js/lan-game-sdk.v1.js",
    "display": {
      "aspectRatio": "16:9",
      "stageTone": "dark"
    },
    "standalone": "local-seats",
    "modes": {
      "solo": false,
      "multiplayer": {
        "kind": "versus",
        "privateRooms": true,
        "minPlayers": 2,
        "maxPlayers": 2,
        "randomSizes": [
          2
        ]
      }
    },
    "capabilities": [
      "room.chat"
    ],
    "contracts": {
      "writeback": "contracts/writeback.json",
      "rules": "contracts/rules.json"
    }
  },
  "writeback": {
    "formatVersion": 1,
    "series": "board",
    "saveVersion": 1,
    "privateFields": {},
    "milestones": [
      {
        "id": "board",
        "label": "棋盘",
        "resumeState": "board"
      }
    ]
  },
  "rules": {
    "engine": "grid-line-v1",
    "size": 3,
    "line": 3
  }
};
