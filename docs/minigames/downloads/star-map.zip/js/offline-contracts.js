window.LanGameOfflineContracts = {
  "config": {
    "formatVersion": 1,
    "gameKey": "star-map",
    "version": "1.0.0",
    "title": "星图拼接",
    "summary": "观察图案与数列，补齐观星台的三块星图。",
    "entry": "main.html",
    "icon": "static/icon.png",
    "sdk": "js/lan-game-sdk.v1.js",
    "display": {
      "aspectRatio": "16:9",
      "stageTone": "dark"
    },
    "standalone": "solo",
    "modes": {
      "solo": true,
      "multiplayer": null
    },
    "capabilities": [],
    "contracts": {
      "writeback": "contracts/writeback.json",
      "rules": "contracts/rules.json"
    }
  },
  "writeback": {
    "formatVersion": 1,
    "series": "stars",
    "saveVersion": 1,
    "privateFields": {},
    "milestones": [
      {
        "id": "first",
        "label": "辨形",
        "resumeState": "first"
      },
      {
        "id": "second",
        "label": "推演",
        "resumeState": "second"
      },
      {
        "id": "third",
        "label": "合图",
        "resumeState": "third"
      }
    ]
  },
  "rules": {
    "engine": "finite-turn-v1",
    "initial": "first",
    "states": {
      "first": {
        "outcome": null
      },
      "second": {
        "outcome": null
      },
      "third": {
        "outcome": null
      },
      "complete": {
        "outcome": "completed"
      }
    },
    "transitions": [
      {
        "from": "first",
        "to": "second",
        "type": "fit",
        "payload": {
          "part": "triangle"
        },
        "actor": "turn",
        "turn": "keep"
      },
      {
        "from": "second",
        "to": "third",
        "type": "fit",
        "payload": {
          "part": "seven"
        },
        "actor": "turn",
        "turn": "keep"
      },
      {
        "from": "third",
        "to": "complete",
        "type": "fit",
        "payload": {
          "part": "spark"
        },
        "actor": "turn",
        "turn": "keep"
      }
    ]
  }
};
